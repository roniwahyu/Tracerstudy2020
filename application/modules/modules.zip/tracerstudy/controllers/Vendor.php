<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends Admin_Controller {

public function __construct()
{
	parent::__construct();
	//Do your magic here
}
	public function index()
	{
		
	}

}

/* End of file Vendor.php */
/* Location: ./application/modules/tracerstudy/controllers/Vendor.php */ ?>