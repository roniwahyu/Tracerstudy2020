<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alumni extends Admin_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}
	public function index()
	{
		
	}

}

/* End of file Alumni.php */
/* Location: ./application/modules/tracerstudy/controllers/Alumni.php */ ?>