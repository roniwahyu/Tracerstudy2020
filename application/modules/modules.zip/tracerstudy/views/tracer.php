		<div class="row" style="margin-top:30px;">
			
        	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        		<?php //print_r($user) ?>
				<?php if(!isset($data)): ?>
					<div class="jumbotron">
						<!-- <div class="container text-center"> -->
							<div class="text-center">
							<h1>Tracer Study 2019</h1>
							<h2>Universitas Widyagama Malang</h2>
							<h2>Alumni</h2>    
							
							</div>
							
							<?php $this->load->view('tracerstudy'); ?>
							
							
						<!-- </div> -->
					</div>
				<?php endif; ?>
				
			</div>
			
		</div>
		