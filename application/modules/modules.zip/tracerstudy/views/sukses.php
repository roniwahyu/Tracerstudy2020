<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Sukses!</strong> Terima kasih atas partisipasi Anda ...
                        <p><a href="<?php echo base_url() ?> " class="btn btn-lg btn-success"><i class="fa fa-chevron-left"></i> Kembali</a> </p>
                    </div>
                </div>
               
            </div>
          
            
</div>

