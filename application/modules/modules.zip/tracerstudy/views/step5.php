<tr>
    <td class="h">f17</td>
    <td valign="top">
        Pada saat lulus, pada tingkat mana kompetensi di bawah ini anda kuasai? (<b>A</b>) <br> Pada saat lulus, bagaimana kontribusi perguruan tinggi dalam hal kompetensi di bawah ini? (<b>B</b>)
    </td>
    <td valign="top">:</td>
    <td>
        <table class="table table-striped table-responsive">
            <tbody>
                <tr>
                    <th colspan="5" style="align:center;">A</th>
                    <th>&nbsp;</th>
                    <th colspan="5">B</th>
                </tr>
                <tr>
                    <th colspan="2">Sangat Rendah</th>
                    <th>&nbsp;</th>
                    <th colspan="2">Sangat Tinggi</th>
                    <th>&nbsp;</th>
                    <th colspan="2">Sangat Rendah</th>
                    <th>&nbsp;</th>
                    <th colspan="2">Sangat Tinggi</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>&nbsp;
                    </th>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                </tr>
                <tr>
                    <td><input name="f1701" value="1" type="radio"></td>
                    <td><input name="f1701" value="2" type="radio"></td>
                    <td><input name="f1701" value="3" type="radio"></td>
                    <td><input name="f1701" value="4" type="radio"></td>
                    <td><input name="f1701" value="5" type="radio"></td>
                    <td>Pengetahuan di bidang atau disiplin ilmu anda <span class="hl">f17-1 f17-2</span></td>
                    <td><input name="f1702" value="1" type="radio"></td>
                    <td><input name="f1702" value="2" type="radio"></td>
                    <td><input name="f1702" value="3" type="radio"></td>
                    <td><input name="f1702" value="4" type="radio"></td>
                    <td><input name="f1702" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1703" value="1" type="radio"></td>
                    <td><input name="f1703" value="2" type="radio"></td>
                    <td><input name="f1703" value="3" type="radio"></td>
                    <td><input name="f1703" value="4" type="radio"></td>
                    <td><input name="f1703" value="5" type="radio"></td>
                    <td>Pengetahuan di luar bidang atau disiplin ilmu anda <span class="hl">f17-3 f17-4</span></td>
                    <td><input name="f1704" value="1" type="radio"></td>
                    <td><input name="f1704" value="2" type="radio"></td>
                    <td><input name="f1704" value="3" type="radio"></td>
                    <td><input name="f1704" value="4" type="radio"></td>
                    <td><input name="f1704" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1705" value="1" type="radio"></td>
                    <td><input name="f1705" value="2" type="radio"></td>
                    <td><input name="f1705" value="3" type="radio"></td>
                    <td><input name="f1705" value="4" type="radio"></td>
                    <td><input name="f1705" value="5" type="radio"></td>
                    <td>Pengetahuan umum <span class="hl">f17-5 f17-6</span></td>
                    <td><input name="f1706" value="1" type="radio"></td>
                    <td><input name="f1706" value="2" type="radio"></td>
                    <td><input name="f1706" value="3" type="radio"></td>
                    <td><input name="f1706" value="4" type="radio"></td>
                    <td><input name="f1706" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1705a" value="1" type="radio"></td>
                    <td><input name="f1705a" value="2" type="radio"></td>
                    <td><input name="f1705a" value="3" type="radio"></td>
                    <td><input name="f1705a" value="4" type="radio"></td>
                    <td><input name="f1705a" value="5" type="radio"></td>
                    <td>Bahasa Inggris <span class="hl">f17-5A f17-6A</span></td>
                    <td><input name="f1706a" value="1" type="radio"></td>
                    <td><input name="f1706a" value="2" type="radio"></td>
                    <td><input name="f1706a" value="3" type="radio"></td>
                    <td><input name="f1706a" value="4" type="radio"></td>
                    <td><input name="f1706a" value="5" type="radio"></td>
                </tr>


                <tr>
                    <td><input name="f1707" value="1" type="radio"></td>
                    <td><input name="f1707" value="2" type="radio"></td>
                    <td><input name="f1707" value="3" type="radio"></td>
                    <td><input name="f1707" value="4" type="radio"></td>
                    <td><input name="f1707" value="5" type="radio"></td>
                    <td>Ketrampilan internet <span class="hl">f17-7 f17-8</span> </td>
                    <td><input name="f1708" value="1" type="radio"></td>
                    <td><input name="f1708" value="2" type="radio"></td>
                    <td><input name="f1708" value="3" type="radio"></td>
                    <td><input name="f1708" value="4" type="radio"></td>
                    <td><input name="f1708" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1709" value="1" type="radio"></td>
                    <td><input name="f1709" value="2" type="radio"></td>
                    <td><input name="f1709" value="3" type="radio"></td>
                    <td><input name="f1709" value="4" type="radio"></td>
                    <td><input name="f1709" value="5" type="radio"></td>
                    <td>Ketrampilan komputer <span class="hl">f17-9 f17-10</span></td>
                    <td><input name="f1710" value="1" type="radio"></td>
                    <td><input name="f1710" value="2" type="radio"></td>
                    <td><input name="f1710" value="3" type="radio"></td>
                    <td><input name="f1710" value="4" type="radio"></td>
                    <td><input name="f1710" value="5" type="radio"></td>
                </tr>


                <tr>
                    <td><input name="f1711" value="1" type="radio"></td>
                    <td><input name="f1711" value="2" type="radio"></td>
                    <td><input name="f1711" value="3" type="radio"></td>
                    <td><input name="f1711" value="4" type="radio"></td>
                    <td><input name="f1711" value="5" type="radio"></td>
                    <td>Berpikir kritis <span class="hl">f17-11 f17-12</span></td>
                    <td><input name="f1712" value="1" type="radio"></td>
                    <td><input name="f1712" value="2" type="radio"></td>
                    <td><input name="f1712" value="3" type="radio"></td>
                    <td><input name="f1712" value="4" type="radio"></td>
                    <td><input name="f1712" value="5" type="radio"></td>
                </tr>


                <tr>
                    <td><input name="f1713" value="1" type="radio"></td>
                    <td><input name="f1713" value="2" type="radio"></td>
                    <td><input name="f1713" value="3" type="radio"></td>
                    <td><input name="f1713" value="4" type="radio"></td>
                    <td><input name="f1713" value="5" type="radio"></td>
                    <td>Ketrampilan riset <span class="hl">f17-13 f17-14</span> </td>
                    <td><input name="f1714" value="1" type="radio"></td>
                    <td><input name="f1714" value="2" type="radio"></td>
                    <td><input name="f1714" value="3" type="radio"></td>
                    <td><input name="f1714" value="4" type="radio"></td>
                    <td><input name="f1714" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1715" value="1" type="radio"></td>
                    <td><input name="f1715" value="2" type="radio"></td>
                    <td><input name="f1715" value="3" type="radio"></td>
                    <td><input name="f1715" value="4" type="radio"></td>
                    <td><input name="f1715" value="5" type="radio"></td>
                    <td>Kemampuan belajar <span class="hl">f17-15 f17-16</span></td>
                    <td><input name="f1716" value="1" type="radio"></td>
                    <td><input name="f1716" value="2" type="radio"></td>
                    <td><input name="f1716" value="3" type="radio"></td>
                    <td><input name="f1716" value="4" type="radio"></td>
                    <td><input name="f1716" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1717" value="1" type="radio"></td>
                    <td><input name="f1717" value="2" type="radio"></td>
                    <td><input name="f1717" value="3" type="radio"></td>
                    <td><input name="f1717" value="4" type="radio"></td>
                    <td><input name="f1717" value="5" type="radio"></td>
                    <td>Kemampuan berkomunikasi <span class="hl">f17-17 f17-18</span></td>
                    <td><input name="f1718" value="1" type="radio"></td>
                    <td><input name="f1718" value="2" type="radio"></td>
                    <td><input name="f1718" value="3" type="radio"></td>
                    <td><input name="f1718" value="4" type="radio"></td>
                    <td><input name="f1718" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1719" value="1" type="radio"></td>
                    <td><input name="f1719" value="2" type="radio"></td>
                    <td><input name="f1719" value="3" type="radio"></td>
                    <td><input name="f1719" value="4" type="radio"></td>
                    <td><input name="f1719" value="5" type="radio"></td>
                    <td>Bekerja di bawah tekanan <span class="hl">f17-19 f17-20</span></td>
                    <td><input name="f1720" value="1" type="radio"></td>
                    <td><input name="f1720" value="2" type="radio"></td>
                    <td><input name="f1720" value="3" type="radio"></td>
                    <td><input name="f1720" value="4" type="radio"></td>
                    <td><input name="f1720" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1721" value="1" type="radio"></td>
                    <td><input name="f1721" value="2" type="radio"></td>
                    <td><input name="f1721" value="3" type="radio"></td>
                    <td><input name="f1721" value="4" type="radio"></td>
                    <td><input name="f1721" value="5" type="radio"></td>
                    <td>Manajemen waktu <span class="hl">f17-21 f17-22</span></td>
                    <td><input name="f1722" value="1" type="radio"></td>
                    <td><input name="f1722" value="2" type="radio"></td>
                    <td><input name="f1722" value="3" type="radio"></td>
                    <td><input name="f1722" value="4" type="radio"></td>
                    <td><input name="f1722" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1723" value="1" type="radio"></td>
                    <td><input name="f1723" value="2" type="radio"></td>
                    <td><input name="f1723" value="3" type="radio"></td>
                    <td><input name="f1723" value="4" type="radio"></td>
                    <td><input name="f1723" value="5" type="radio"></td>
                    <td>Bekerja secara mandiri <span class="hl">f17-23 f17-24</span></td>
                    <td><input name="f1724" value="1" type="radio"></td>
                    <td><input name="f1724" value="2" type="radio"></td>
                    <td><input name="f1724" value="3" type="radio"></td>
                    <td><input name="f1724" value="4" type="radio"></td>
                    <td><input name="f1724" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1725" value="1" type="radio"></td>
                    <td><input name="f1725" value="2" type="radio"></td>
                    <td><input name="f1725" value="3" type="radio"></td>
                    <td><input name="f1725" value="4" type="radio"></td>
                    <td><input name="f1725" value="5" type="radio"></td>
                    <td>Bekerja dalam tim/bekerjasama dengan orang lain <span class="hl">f17-25 f17-26</span></td>
                    <td><input name="f1726" value="1" type="radio"></td>
                    <td><input name="f1726" value="2" type="radio"></td>
                    <td><input name="f1726" value="3" type="radio"></td>
                    <td><input name="f1726" value="4" type="radio"></td>
                    <td><input name="f1726" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1727" value="1" type="radio"></td>
                    <td><input name="f1727" value="2" type="radio"></td>
                    <td><input name="f1727" value="3" type="radio"></td>
                    <td><input name="f1727" value="4" type="radio"></td>
                    <td><input name="f1727" value="5" type="radio"></td>
                    <td>Kemampuan dalam memecahkan masalah <span class="hl">f17-27 f17-28</span></td>
                    <td><input name="f1728" value="1" type="radio"></td>
                    <td><input name="f1728" value="2" type="radio"></td>
                    <td><input name="f1728" value="3" type="radio"></td>
                    <td><input name="f1728" value="4" type="radio"></td>
                    <td><input name="f1728" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1729" value="1" type="radio"></td>
                    <td><input name="f1729" value="2" type="radio"></td>
                    <td><input name="f1729" value="3" type="radio"></td>
                    <td><input name="f1729" value="4" type="radio"></td>
                    <td><input name="f1729" value="5" type="radio"></td>
                    <td>Negosiasi <span class="hl">f17-29 f17-30</span></td>
                    <td><input name="f1730" value="1" type="radio"></td>
                    <td><input name="f1730" value="2" type="radio"></td>
                    <td><input name="f1730" value="3" type="radio"></td>
                    <td><input name="f1730" value="4" type="radio"></td>
                    <td><input name="f1730" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1731" value="1" type="radio"></td>
                    <td><input name="f1731" value="2" type="radio"></td>
                    <td><input name="f1731" value="3" type="radio"></td>
                    <td><input name="f1731" value="4" type="radio"></td>
                    <td><input name="f1731" value="5" type="radio"></td>
                    <td>Kemampuan analisis <span class="hl">f17-31 f17-32</span></td>
                    <td><input name="f1732" value="1" type="radio"></td>
                    <td><input name="f1732" value="2" type="radio"></td>
                    <td><input name="f1732" value="3" type="radio"></td>
                    <td><input name="f1732" value="4" type="radio"></td>
                    <td><input name="f1732" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1733" value="1" type="radio"></td>
                    <td><input name="f1733" value="2" type="radio"></td>
                    <td><input name="f1733" value="3" type="radio"></td>
                    <td><input name="f1733" value="4" type="radio"></td>
                    <td><input name="f1733" value="5" type="radio"></td>
                    <td>Toleransi <span class="hl">f17-33 f17-34</span></td>
                    <td><input name="f1734" value="1" type="radio"></td>
                    <td><input name="f1734" value="2" type="radio"></td>
                    <td><input name="f1734" value="3" type="radio"></td>
                    <td><input name="f1734" value="4" type="radio"></td>
                    <td><input name="f1734" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1735" value="1" type="radio"></td>
                    <td><input name="f1735" value="2" type="radio"></td>
                    <td><input name="f1735" value="3" type="radio"></td>
                    <td><input name="f1735" value="4" type="radio"></td>
                    <td><input name="f1735" value="5" type="radio"></td>
                    <td>Kemampuan adaptasi <span class="hl">f17-35 f17-36</span></td>
                    <td><input name="f1736" value="1" type="radio"></td>
                    <td><input name="f1736" value="2" type="radio"></td>
                    <td><input name="f1736" value="3" type="radio"></td>
                    <td><input name="f1736" value="4" type="radio"></td>
                    <td><input name="f1736" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1737" value="1" type="radio"></td>
                    <td><input name="f1737" value="2" type="radio"></td>
                    <td><input name="f1737" value="3" type="radio"></td>
                    <td><input name="f1737" value="4" type="radio"></td>
                    <td><input name="f1737" value="5" type="radio"></td>
                    <td>Loyalitas<span class="hl">f17-37 f17-38</span></td>
                    <td><input name="f1738" value="1" type="radio"></td>
                    <td><input name="f1738" value="2" type="radio"></td>
                    <td><input name="f1738" value="3" type="radio"></td>
                    <td><input name="f1738" value="4" type="radio"></td>
                    <td><input name="f1738" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1737a" value="1" type="radio"></td>
                    <td><input name="f1737a" value="2" type="radio"></td>
                    <td><input name="f1737a" value="3" type="radio"></td>
                    <td><input name="f1737a" value="4" type="radio"></td>
                    <td><input name="f1737a" value="5" type="radio"></td>
                    <td>Integritas <span class="hl">f17-37A f17-38A</span></td>
                    <td><input name="f1738a" value="1" type="radio"></td>
                    <td><input name="f1738a" value="2" type="radio"></td>
                    <td><input name="f1738a" value="3" type="radio"></td>
                    <td><input name="f1738a" value="4" type="radio"></td>
                    <td><input name="f1738a" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1739" value="1" type="radio"></td>
                    <td><input name="f1739" value="2" type="radio"></td>
                    <td><input name="f1739" value="3" type="radio"></td>
                    <td><input name="f1739" value="4" type="radio"></td>
                    <td><input name="f1739" value="5" type="radio"></td>
                    <td>Bekerja dengan orang yang berbeda budaya maupun latar belakang <span class="hl">f17-39 f17-40</span></td>
                    <td><input name="f1740" value="1" type="radio"></td>
                    <td><input name="f1740" value="2" type="radio"></td>
                    <td><input name="f1740" value="3" type="radio"></td>
                    <td><input name="f1740" value="4" type="radio"></td>
                    <td><input name="f1740" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1741" value="1" type="radio"></td>
                    <td><input name="f1741" value="2" type="radio"></td>
                    <td><input name="f1741" value="3" type="radio"></td>
                    <td><input name="f1741" value="4" type="radio"></td>
                    <td><input name="f1741" value="5" type="radio"></td>
                    <td>Kepemimpinan <span class="hl">f17-41 f17-42</span></td>
                    <td><input name="f1742" value="1" type="radio"></td>
                    <td><input name="f1742" value="2" type="radio"></td>
                    <td><input name="f1742" value="3" type="radio"></td>
                    <td><input name="f1742" value="4" type="radio"></td>
                    <td><input name="f1742" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1743" value="1" type="radio"></td>
                    <td><input name="f1743" value="2" type="radio"></td>
                    <td><input name="f1743" value="3" type="radio"></td>
                    <td><input name="f1743" value="4" type="radio"></td>
                    <td><input name="f1743" value="5" type="radio"></td>
                    <td>Kemampuan dalam memegang tanggungjawab <span class="hl">f17-43 f17-44</span></td>
                    <td><input name="f1744" value="1" type="radio"></td>
                    <td><input name="f1744" value="2" type="radio"></td>
                    <td><input name="f1744" value="3" type="radio"></td>
                    <td><input name="f1744" value="4" type="radio"></td>
                    <td><input name="f1744" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1745" value="1" type="radio"></td>
                    <td><input name="f1745" value="2" type="radio"></td>
                    <td><input name="f1745" value="3" type="radio"></td>
                    <td><input name="f1745" value="4" type="radio"></td>
                    <td><input name="f1745" value="5" type="radio"></td>
                    <td>Inisiatif <span class="hl">f17-45 f17-46</span></td>
                    <td><input name="f1746" value="1" type="radio"></td>
                    <td><input name="f1746" value="2" type="radio"></td>
                    <td><input name="f1746" value="3" type="radio"></td>
                    <td><input name="f1746" value="4" type="radio"></td>
                    <td><input name="f1746" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1747" value="1" type="radio"></td>
                    <td><input name="f1747" value="2" type="radio"></td>
                    <td><input name="f1747" value="3" type="radio"></td>
                    <td><input name="f1747" value="4" type="radio"></td>
                    <td><input name="f1747" value="5" type="radio"></td>
                    <td>Manajemen proyek/program <span class="hl">f17-47 f17-48</span></td>
                    <td><input name="f1748" value="1" type="radio"></td>
                    <td><input name="f1748" value="2" type="radio"></td>
                    <td><input name="f1748" value="3" type="radio"></td>
                    <td><input name="f1748" value="4" type="radio"></td>
                    <td><input name="f1748" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1749" value="1" type="radio"></td>
                    <td><input name="f1749" value="2" type="radio"></td>
                    <td><input name="f1749" value="3" type="radio"></td>
                    <td><input name="f1749" value="4" type="radio"></td>
                    <td><input name="f1749" value="5" type="radio"></td>
                    <td>Kemampuan untuk memresentasikan ide/produk/laporan <span class="hl">f17-49 f17-50</span></td>
                    <td><input name="f1750" value="1" type="radio"></td>
                    <td><input name="f1750" value="2" type="radio"></td>
                    <td><input name="f1750" value="3" type="radio"></td>
                    <td><input name="f1750" value="4" type="radio"></td>
                    <td><input name="f1750" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1751" value="1" type="radio"></td>
                    <td><input name="f1751" value="2" type="radio"></td>
                    <td><input name="f1751" value="3" type="radio"></td>
                    <td><input name="f1751" value="4" type="radio"></td>
                    <td><input name="f1751" value="5" type="radio"></td>
                    <td>Kemampuan dalam menulis laporan, memo dan dokumen <span class="hl">f17-51 f17-52</span></td>
                    <td><input name="f1752" value="1" type="radio"></td>
                    <td><input name="f1752" value="2" type="radio"></td>
                    <td><input name="f1752" value="3" type="radio"></td>
                    <td><input name="f1752" value="4" type="radio"></td>
                    <td><input name="f1752" value="5" type="radio"></td>
                </tr>

                <tr>
                    <td><input name="f1753" value="1" type="radio"></td>
                    <td><input name="f1753" value="2" type="radio"></td>
                    <td><input name="f1753" value="3" type="radio"></td>
                    <td><input name="f1753" value="4" type="radio"></td>
                    <td><input name="f1753" value="5" type="radio"></td>
                    <td>Kemampuan untuk terus belajar sepanjang hayat <span class="hl">f17-53 f17-54</span></td>
                    <td><input name="f1754" value="1" type="radio"></td>
                    <td><input name="f1754" value="2" type="radio"></td>
                    <td><input name="f1754" value="3" type="radio"></td>
                    <td><input name="f1754" value="4" type="radio"></td>
                    <td><input name="f1754" value="5" type="radio"></td>
                </tr>

            </tbody>
        </table>
    </td>
</tr>