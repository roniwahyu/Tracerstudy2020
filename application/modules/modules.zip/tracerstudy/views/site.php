		<div class="row" style="margin-top:30px;">
			
        	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<?php if(!isset($data)): ?>
					<div class="jumbotron home">
						<div class="container text-center">
							<h1>Tracert Study</h1>
							<h2>2016</h2>
							<h3>Universitas Widyagama Malang</h3>
							<p>&nbsp;</p>
							
							
						</div>
					</div>
				<?php endif; ?>
				
			</div>
			
		</div>
		
	