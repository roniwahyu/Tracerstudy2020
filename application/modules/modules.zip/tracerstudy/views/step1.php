
<tr>
    <td colspan="4"><b>Tracer Study</b></td>
</tr>
<tr>
    <td id="f3" class="h">f3</td>
    <td valign="top">Kapan anda mulai mencari pekerjaan? <i>Mohon pekerjaan sambilan tidak dimasukkan</i></td>
    <td valign="top">:</td>
    <td>
        <table class="table table-striped table-responsive">
            <tbody>
                <tr>
                    <td><span class="hl">f301</span>&nbsp;&nbsp;<input class="form-control" id="f301" name="f301" value="1" onclick="show3()" type="radio"> [1] Kira-kira <input class="form-control" name="f302" value="" size="5" type="text"> &nbsp;bulan sebelum lulus &nbsp;&nbsp;<span class="hl">f302</span></td>
                </tr>
                <tr>
                    <td><span class="hl">f301</span>&nbsp;&nbsp;<input class="form-control" id="f302" name="f301" value="2" onclick="show3()" type="radio"> [2] Kira-kira <input class="form-control" name="f303" value="" size="5" type="text"> &nbsp;bulan sesudah lulus &nbsp;&nbsp;<span class="hl">f303</span></td>
                </tr>
                <tr>
                    <td><span class="hl">f301</span>&nbsp;&nbsp;<input class="form-control" id="f303" name="f301" value="3" onclick="hide3()" type="radio"> [3] Saya tidak mencari kerja (<i>Langsung ke pertanyaan f8</i>)</td>
                </tr>
            </tbody>
        </table>
    </td>
 </tr>