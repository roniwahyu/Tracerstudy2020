
<div class="post">
	<!-- <form class="form-horizontal" role="form" enctype="multipart/form-data" id="quizform" action="<?php //echo base_url('tracerstudy/submit') ?>" method="POST"> -->
		
					
			<?php $this->load->view('step0-2019') ?>
			

		
		<!-- <button id="savequiz" type="submit" class="btn btn-primary">Submit</button> -->
	<!-- </form> -->
</div>

	
