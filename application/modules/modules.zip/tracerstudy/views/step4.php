<tr style="display: table-row;" id="f12">
    <td class="h">f12</td>
    <td valign="top">Tempat anda bekerja saat ini bergerak di bidang apa? (Klasifikasi Baku Lapangan Usaha Indonesia, Kemnakertrans, 2009)
    </td>
    <td valign="top">:</td>
    <td>
        <select name="f12">
<option value="01"> [01] Pertanian tanaman, peternakan, perburuan dan kegiatan yang berhubungan dengan itu 
</option><option value="02"> [02] Kehutanan dan penebangan kayu 
</option><option value="03"> [03] Perikanan 
</option><option value="04">[04] Pertambangan batu bara dan lignit 
</option><option value="05">[05] Pertambangan minyak bumi dan gas alam dan panas bumi 
</option><option value="06">[06] Pertambangan bijih logam 
</option><option value="07">[07] Pertambangan dan penggalian lainnya 
</option><option value="08">[08] Jasa pertambangan 
</option><option value="09">[09] Industri makanan 
</option><option value="10">[10] Industri minuman 
</option><option value="11">[11] Industri pengolahan tembakau 
</option><option value="12">[12] Industri tekstil 
</option><option value="13">[13] Industri pakaian jadi 
</option><option value="14">[14] Industri kulit, barang dari kulit dan alas kaki 
</option><option value="15">[15] Industri kayu, barang dari kayu dan gabus (tidak termasuk furnitur) dan barang anyaman dari bambu, rotan dan sejenisnya 
</option><option value="16">[16] Industri kertas dan barang dari kertas 
</option><option value="17">[17] Industri pencetakan dan reproduksi media rekaman 
</option><option value="18">[18] Industri produk dari batu bara dan pengilangan minyak bumi 
</option><option value="19">[19] Industri bahan kimia dan barang dari bahan kimia 
</option><option value="20">[20] Industri farmasi, produk obat kimia dan obat tradisional 
</option><option value="21">[21] Industri karet, barang dari karet dan plastik 
</option><option value="22">[22] Industri barang galian bukan logam 
</option><option value="23">[23] Industri logam dasar  
</option><option value="24">[24] Industri barang logam, bukan mesin dan peralatannya 
</option><option value="25">[25] Industri komputer, barang elektronik dan optik 
</option><option value="26">[26] Industri peralatan listrik 
</option><option value="27">[27] Industri mesin dan perlengkapan ytdl 
</option><option value="28">[28] Industri kendaraan bermotor, trailer dan semi trailer 
</option><option value="29">[29] Industri alat angkutan lainnya 
</option><option value="30">[30] Industri furnitur 
</option><option value="31">[31] Industri pengolahan lainnya 
</option><option value="32">[32] Jasa reparasi dan pemasangan mesin dan peralatan 
</option><option value="33">[33] Pengadaan listrik, gas, uap/air panas dan udara dingin 
</option><option value="34">[34] Pengadaan air 
</option><option value="35">[35] Pengolahan limbah 
</option><option value="36">[36] Pengolahan sampah dan daur ulang 
</option><option value="37">[37] Jasa pembersihan dan pengelolaan sampah lainnya 
</option><option value="38">[38] Konstruksi gedung 
</option><option value="39">[39] Konstruksi bangunan sipil 
</option><option value="40">[40] Konstruksi khusus 
</option><option value="41">[41] Perdagangan, reparasi dan perawatan mobil dan sepeda motor 
</option><option value="42">[42] Perdagangan besar, bukan mobil dan sepeda motor 
</option><option value="43">[43] Perdagangan eceran, bukan mobil dan motor
</option><option value="44">[44] Angkutan darat dan angkutan melalui saluran pipa
</option><option value="88">[88] Angkutan Air
</option><option value="45">[45] Angkutan udara
</option><option value="46">[46] Pergudangan dan jasa penunjang angkutan
</option><option value="47">[47] Pos dan kurir
</option><option value="48">[48] Penyediaan akomodasi
</option><option value="49">[49] Penyediaan makanan dan minuman
</option><option value="50">[50] Penerbitan
</option><option value="51">[51] Produksi gambar bergerak, video dan program televisi, perekaman suara dan penerbitan musik
</option><option value="52">[52] Penyiaran dan pemrograman
</option><option value="53">[53] Telekomunikasi
</option><option value="54">[54] Kegiatan pemrograman, konsultasi komputer dan kegiatan yang berhubungan dengan itu
</option><option value="55">[55] Kegiatan jasa informasi
</option><option value="56">[56] Jasa keuangan, bukan asuransi dan dana pensiun
</option><option value="57">[57] Asuransi, reasuransi dan dana pensiun, bukan jaminan sosial wajib
</option><option value="58">[58] Jasa penunjang jasa keuangan, asuransi dan dana pensiun
</option><option value="59">[59] Real estat
</option><option value="60">[60] Jasa hukum dan akuntansi
</option><option value="61">[61] Kegiatan kantor pusat dan konsultasi manajemen
</option><option value="62">[62] Jasa arsitektur dan teknik sipil; analisis dan uji teknis
</option><option value="63">[63] Penelitian dan pengembangan ilmu pengetahuan
</option><option value="64">[64] Periklanan dan penelitian pasar
</option><option value="65">[65] Jasa profesional, ilmiah dan teknis lainnya
</option><option value="66">[66] Jasa kesehatan hewan
</option><option value="67">[67] Jasa persewaan dan sewa guna usaha tanpa hak opsi
</option><option value="68">[68] Jasa ketenagakerjaan
</option><option value="69">[69] Jasa agen perjalanan, penyelenggara tur dan jasa reservasi lainnya
</option><option value="70">[70] Jasa keamanan dan penyelidikan
</option><option value="71">[71] Jasa untuk gedung dan pertamanan
</option><option value="72">[72] Jasa administrasi kantor, jasa penunjang kantor dan jasa penunjang usaha lainnya
</option><option value="73">[73] Administrasi pemerintahan, pertahanan dan jaminan sosial wajib
</option><option value="74">[74] Jasa pendidikan
</option><option value="75">[75] Jasa kesehatan manusia
</option><option value="76">[76] Jasa kegiatan sosial di dalam panti
</option><option value="77">[77] Jasa kegiatan sosial di luar panti
</option><option value="78">[78] Kegiatan hiburan, kesenian dan kreativitas
</option><option value="79">[79] Perpustakaan, arsip, museum dan kegiatan kebudayaan lainnya
</option><option value="80">[80] Kegiatan perjudian dan pertaruhan
</option><option value="81">[81] Kegiatan olahraga dan rekreasi lainnya
</option><option value="82">[82] Kegiatan keanggotaan organisasi
</option><option value="83">[83] Jasa reparasi komputer dan barang keperluan pribadi dan perlengkapan rumah tangga
</option><option value="84">[84] Jasa perorangan lainnya
</option><option value="85">[85] Jasa perorangan yang melayani rumah tangga
</option><option value="86">[86] Kegiatan yang menghasilkan barang dan jasa oleh rumah tangga yang digunakan sendiri untuk memenuhi kebutuhan
</option><option value="87">[87] Kegiatan badan internasional dan badan ekstra internasional lainnya
</option></select>

    </td>
</tr>

<tr style="display: table-row;" id="f13">
    <td class="h">f13</td>
    <td valign="top">Kira-kira berapa pendapatan anda setiap bulannya?
    </td>
    <td valign="top">:</td>
    <td>
        <table class="table table-striped table-responsive">
            <tbody>
                <tr>
                    <td>Dari Pekerjaan Utama</td>
                    <td> Rp. &nbsp;
                        <input name="f1301" value="0" size="20" type="text"><span class="hl">(f13-01)</span> (Isilah dengan ANGKA saja, tanpa tanda Titik atau Koma)</td>
                </tr>
                <tr>
                    <td>Dari Lembur dan Tips</td>
                    <td> Rp. &nbsp;
                        <input name="f1302" value="0" size="20" type="text"><span class="hl">(f13-02)</span> (Isilah dengan ANGKA saja, tanpa tanda Titik atau Koma)</td>
                </tr>
                <tr>
                    <td>Dari Pekerjaan Lainnya</td>
                    <td> Rp. &nbsp;
                        <input name="f1303" value="0" size="20" type="text"><span class="hl">(f13-03)</span> (Isilah dengan ANGKA saja, tanpa tanda Titik atau Koma)</td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>
<tr style="display: table-row;" id="f14">
    <td class="h">f14</td>
    <td valign="top">
        Seberapa erat hubungan antara bidang studi dengan pekerjaan anda?
    </td>
    <td valign="top">:</td>
    <td>
        <span>
		<input name="f14" value="1" type="radio"> [1] Sangat Erat<br>
		<input name="f14" value="2" type="radio"> [2] Erat<br>
		<input name="f14" value="3" type="radio"> [3] Cukup Erat<br>
		<input name="f14" value="4" type="radio"> [4] Kurang Erat<br>
		<input name="f14" value="5" type="radio"> [5] Tidak Sama Sekali <br>
		</span>
    </td>
</tr>

<tr style="display: table-row;" id="f15">
    <td class="h">f15</td>
    <td valign="top">
        Tingkat pendidikan apa yang paling tepat/sesuai untuk pekerjaan anda saat ini?
    </td>
    <td valign="top">:</td>
    <td>
        <span>
		<input name="f15" value="1" type="radio"> [1] Setingkat Lebih Tinggi<br>
		<input name="f15" value="2" type="radio"> [2] Tingkat yang Sama<br>
		<input name="f15" value="3" type="radio"> [3] Setingkat Lebih Rendah<br>
		<input name="f15" value="4" type="radio"> [4] Tidak Perlu Pendidikan Tinggi<br>
		</span>
    </td>
</tr>

<tr style="display: table-row;" id="f16">
    <td class="h">f16</td>
    <td valign="top">
        Jika menurut anda pekerjaan anda saat ini tidak sesuai dengan pendidikan anda, mengapa anda mengambilnya? Jawaban bisa lebih dari satu
    </td>
    <td valign="top">:</td>
    <td>
        <span>
        <input name="f1601" value="1" type="checkbox"> [1] Pertanyaan tidak sesuai; pekerjaan saya sekarang sudah sesuai dengan pendidikan saya. <span class="hl">f16-01</span><br>
        <input name="f1602" value="2" type="checkbox"> [2] Saya belum mendapatkan pekerjaan yang lebih sesuai.<span class="hl">f16-02</span><br>
        <input name="f1603" value="3" type="checkbox"> [3] Di pekerjaan ini saya memeroleh prospek karir yang baik. <span class="hl">f16-03</span><br>
        <input name="f1604" value="4" type="checkbox"> [4] Saya lebih suka bekerja di area pekerjaan yang tidak ada hubungannya dengan pendidikan saya. <span class="hl">f16-04</span><br>
        <input name="f1605" value="5" type="checkbox"> [5] Saya dipromosikan ke posisi yang kurang berhubungan dengan pendidikan saya dibanding posisi sebelumnya.<span class="hl">f16-05</span><br>
        <input name="f1606" value="6" type="checkbox"> [6] Saya dapat memeroleh pendapatan yang lebih tinggi di pekerjaan ini. <span class="hl">f16-06</span><br>
        <input name="f1607" value="7" type="checkbox"> [7] Pekerjaan saya saat ini lebih aman/terjamin/secure <span class="hl">f16-07</span><br>
        <input name="f1608" value="8" type="checkbox"> [8] Pekerjaan saya saat ini lebih menarik <span class="hl">f16-08</span><br>
        <input name="f1609" value="9" type="checkbox"> [9] Pekerjaan saya saat ini lebih memungkinkan saya mengambil pekerjaan tambahan/jadwal yang fleksibel, dll.<span class="hl">f16-09</span><br>
        <input name="f1610" value="10" type="checkbox"> [10] Pekerjaan saya saat ini lokasinya lebih dekat dari rumah saya. <span class="hl">f16-10</span><br>
        <input name="f1611" value="11" type="checkbox"> [11] Pekerjaan saya saat ini dapat lebih menjamin kebutuhan keluarga saya. <span class="hl">f16-11</span><br>
        <input name="f1612" value="12" type="checkbox"> [12] Pada awal meniti karir ini, saya harus menerima pekerjaan yang tidak berhubungan dengan pendidikan saya. <span class="hl">f16-12</span><br>
        <input name="f1613" value="13" type="checkbox"> [13] Lainnya: <span class="hl">f16-13</span><br>
        <input name="f1614" size="60" value="" maxlength="80" type="text"><span class="hl">f16-14</span>
        </span>
    </td>
</tr>