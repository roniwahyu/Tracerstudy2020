<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/
class Tracerstudy_model extends CI_Model {

	function __construct(){
		parent::__construct();
	}

	
    
 
     //Update 30122014 SWI
    //untuk Array Dropdown dari database yang lain
    
}

/* End of file site_model.php */
/* Location: ./ */
 ?>